<!doctype html>
<html>
<body>
	<h1>Contact Request</h1>
	<p>Name: {{$name}}</p>
	<p>Subject: {{$subject}}</p>
	<p>Email: {{$email}}</p>
	<p>Message: {{$message}}</p>
</body>
</html>