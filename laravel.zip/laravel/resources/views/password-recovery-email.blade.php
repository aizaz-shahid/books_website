<!doctype html>
<html>
<body>
	<h1>Welcome to obooko.com</h1>
	<p>Hi {{$name}},<br> Your password is {{$password}}</p>
</body>
</html>