<!doctype html>
<html>
<body>
	<h1>Author Book Submit</h1>
	<p>Name of the book: {{$book}}</p>
	<p>Category: {{$category}}</p>
	<p>Name of Author: {{$author}}</p>
	
</body>
</html>