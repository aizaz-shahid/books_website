<!doctype html>
<html>
<body>
	<h1>Book Feedback</h1>
	<p>Name of the book: {{$name}}</p>
	<p>Name of the person: {{$subject}}</p>
	<p>Sender's Email: {{$email}}</p>
	
</body>
</html>