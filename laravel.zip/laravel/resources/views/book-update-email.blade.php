<!doctype html>
<html>
<body>
	<h1>Book Update</h1>
	<p>Book Title: {{$book}}</p>
	<p>Author Name: {{$author}}</p>
	
</body>
</html>